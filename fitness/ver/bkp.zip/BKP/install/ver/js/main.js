$(function () {

    $(".ui-br").css("border", "none");
    
  console.log("teste");
});